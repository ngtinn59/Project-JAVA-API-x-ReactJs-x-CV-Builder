import { PersonalProjectType } from "../../../../utils/type";

type Props = {
  personalProjects: PersonalProjectType[];
};

export default function PersonalsProjectSection({ personalProjects }: Props) {
  return (
    <div className="grid grid-cols-12 gap-4">
      <p className="text-bold text-center md:text-start font-bold col-span-2 !text-base">
        Personal Projects
      </p>
      <div className="text-bold col-span-10 text-base">
        {personalProjects.map((project, index) => (
          <div
            className="flex flex-col gap-2 flex-nowrap"
            key={"personal-project-" + index}
          >
            <div className="flex flex-col  flex-nowrap">
              <div className="text-base  text-bold font-medium">
                {project.start_date} - {project.end_date}
              </div>
              <div className="flex flex-row gap-2  flex-nowrap font-bold">
                <div className="text-base  text-bold ">{project.title}</div>

                <span>|</span>
                <p className="text-bold text-base ">
                  {project.start_date} - {project.end_date}
                </p>
              </div>
            </div>

            <div
              className=" text-base text-bold "
              dangerouslySetInnerHTML={{
                __html: project.description,
              }}
            ></div>
          </div>
        ))}
      </div>
    </div>
  );
}
